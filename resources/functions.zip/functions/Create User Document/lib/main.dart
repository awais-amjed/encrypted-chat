import 'dart:convert';

import 'package:dart_appwrite/dart_appwrite.dart';

Future<void> start(final request, final response) async {
  Client client = Client();

  client
      .setEndpoint(request.env['endpoint'])
      .setProject(request.env['projectID'])
      .setKey(request.env['apiKey']);

  final data = json.decode(request.env['APPWRITE_FUNCTION_EVENT_DATA']);

  Database database = Database(client);

  await database
      .createDocument(collectionId: 'users', documentId: data['\$id'], data: {
    'name': data['name'],
  }, read: [
    'role:all'
  ], write: [
    'user:${data['\$id']}'
  ]).then((value) async {
    await database.createDocument(
      collectionId: 'notifications',
      documentId: data['\$id'],
      data: {
        'user_ids': [],
      },
      read: ['user:${data['\$id']}'],
      write: ['role:member'],
    );
  });
}
