import 'package:dart_appwrite/dart_appwrite.dart';

Future doTheMagic({
  required Database database,
  required String user1,
  required String user2,
}) async {
  final String collectionID =
      '${user1.substring(user1.length - 16)}-${user2.substring(user1.length - 16)}';

  await database.createCollection(
    name: collectionID,
    collectionId: collectionID,
    permission: 'collection',
    read: ['user:$user1', 'user:$user2'],
    write: ['user:$user2', 'user:$user1'],
  ).then((value) async {
    await database.createStringAttribute(
      collectionId: collectionID,
      key: 'data',
      size: 500,
      xrequired: true,
      array: true,
    );
    await Future.delayed(const Duration(milliseconds: 500));
    await database.createDocument(
        collectionId: collectionID,
        documentId: 'partitions',
        data: {
          'data': ['1']
        });
    await database.createDocument(
        collectionId: collectionID, documentId: '1', data: {'data': []});
  });
}

Future<void> start(final request, final response) async {
  Client client = Client();

  client
      .setEndpoint(request.env['endpoint'])
      .setProject(request.env['projectID'])
      .setKey(request.env['apiKey']);

  final data = request.payload.split('-');
  final String user1 = data[0].toString();
  final String user2 = data[1].toString();

  Database database = Database(client);

  await Future.wait([
    doTheMagic(database: database, user1: user1, user2: user2),
    doTheMagic(database: database, user1: user2, user2: user1)
  ]);
}
