import 'package:dart_appwrite/dart_appwrite.dart';

Future<void> start(final request, final response) async {
  Client client = Client();

  client
      .setEndpoint(request.env['endpoint'])
      .setProject(request.env['projectID'])
      .setKey(request.env['apiKey']);

  final data = request.payload.split('-');
  final String user1 = data[0].toString();
  final String user2 = data[1].toString();

  Database database = Database(client);

  await database
      .getDocument(
    collectionId: 'notifications',
    documentId: user2,
  )
      .then((value) async {
    List<String>? userIDs =
        value.data['user_ids']?.map<String>((e) => e.toString()).toList();
    if (userIDs != null && userIDs.contains(user1)) {
      return;
    }
    userIDs ??= <String>[];
    userIDs.add(user1);
    await database.updateDocument(
        collectionId: 'notifications',
        documentId: user2,
        data: {
          'user_ids': userIDs,
        });
  });
}
